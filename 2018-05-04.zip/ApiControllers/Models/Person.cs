﻿namespace ApiControllers.Models {

    public class Person {
        public int PersonId { get; set; }
        public string Name { get; set; }
        public string Post { get; set; }
        public string Phone { get; set; }
    }
}
