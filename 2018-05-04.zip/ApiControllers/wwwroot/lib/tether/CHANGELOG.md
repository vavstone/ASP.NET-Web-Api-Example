## v1.3.0
- Tether instances now fire an 'update' event when attachments change due to constraints (#119)

## v1.0.1
- Update arrow mixin to change arrow pointer event


## v1.0.0
- Coffeescript -> ES6
- Proper UMD Wrapper
- Update build steps
- Add changelog
- Provide minified CSS
